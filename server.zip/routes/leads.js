const express = require('express');
const router = express.Router();
const Lead = require('../models/Lead');

router.get('/', async (req, res) => {
  const leads = await Lead.find().sort({ createdAt: -1 });
  res.json(leads);
});

router.post('/', async (req, res) => {
  const newLead = new Lead(req.body);
  await newLead.save();
  res.json(newLead);
});

router.put('/:id', async (req, res) => {
  const updatedLead = await Lead.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updatedLead);
});

router.delete('/:id', async (req, res) => {
  await Lead.findByIdAndDelete(req.params.id);
  res.json({ message: 'Lead deleted' });
});

module.exports = router;